SYNTHETIC TEST DATA ONLY. Values are invented solely to test parsing; they are not research results.
