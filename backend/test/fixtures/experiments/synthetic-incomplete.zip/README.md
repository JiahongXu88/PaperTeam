SYNTHETIC INCOMPLETE TEST DATA. Protocol deliberately missing.
